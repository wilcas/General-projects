Welcome to Pythesizer!

FUNCTION:
This program is a music synthesizer in which the user can modify pre-loaded .wav files and record them into recordings and play them back. The user can also temporarily save recordings into larger projects. 

INSTALLATION/REQUIREMENTS:
This program utilizes modules in the standard python library as well as the latest versions of numpy, scipy, and scikits.samplerate. All of these claim to have support in the future.

Links to download modules
Numpy and SciPy:http://www.numpy.org
- These modules have instructions to install on their website, a mac may require a brew or pip install.
-version 1.8.1

Scikits.samplerate:pypi.python.org/pypi/scikits.samplerate
-requirements for install can be found at: 
 http://www.ar.media.kyoto-u.ac.jp/members/david/softwares/samplerate/sphinx/installing.html#id1
- this can be done using brew install and possibly pip install depending on your machine
- version 0.3.3
